const express = require("express");
const bodyParser = require("body-parser");
const router = require("./controller");
const formidable = require('formidable');
const path = require("path");
const fs = require("fs");
const sd = require("silly-datetime");
const session = require('express-session');
const cookieParser = require('cookie-parser');
const crypto = require("crypto");
const multipart = require("connect-multiparty");
const admin_logo = require("./admin_logo");
const commodity = require("./commodity");
const share = require("./tool");
const MongoClient = share.MongoClient;
const url = share.url;
const ObjectId = share.objectId;
const app = express();
const multipartMiddleware = multipart();

app.set("view engine", "ejs");
app.use(cookieParser());
app.use(session({
    secret: 'recommand 128 bytes random string',
    name: 'lv',
    resave: false,
    saveUninitialized: true
}));
app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By", ' 3.2.1');
    next();
})
var jsonParser = bodyParser.json();
app.use(bodyParser.urlencoded({
    extended: false
}))



function databaseQuery(Data, DataSe, obj, req, res, callback) {
    var boole = {};
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db(Data).collection(DataSe);
        dbo.find(obj).toArray(function (err, items) {
            if (err) {
                db.close();
                return;
            }
            if (items.length) {
                boole = items;
            } else {
                boole.noThing = "0"
            }
            res.end(JSON.stringify(boole));
            db.close();
        })
    })
}
app.post("/tuijia", function (req, res) {
    var obj = {
        recommend: "1"
    };
    databaseQuery("mongo", "inquireDatas", obj, req, res);
})
app.post("/admin/", jsonParser, function (req, res) {
    var form = new formidable.IncomingForm();
    form.encoding = 'utf-8';
    form.uploadDir = path.join(__dirname + "/staticPage/img");
    form.keepExtensions = true; //保留后缀
    form.maxFieldsSize = 2 * 1024 * 1024;

    form.parse(req, function (err, fields, files, next) {
        if (err) {
            return;
        }
        var ttt = sd.format(new Date(), 'YYYYMMDDHHmmss');
        var ran = parseInt(Math.random() * 89999 + 10000);
        var extname = path.extname(files.tupian.name);
        var oldpath = files.tupian.path;
        var newpath = path.normalize(__dirname + "/staticPage/imgs/" + ttt + ran + extname);
        fs.rename(oldpath, newpath, function (err) {
            if (err) {
                res.send("改名失败");
                return;
            }
            fields.img = path.normalize("./imgs/" + ttt + ran + extname);
            fields.salesVolume = 0;
            fields.evaluate = 0;
            MongoClient.connect(url, function (err, db) {
                if (err) {
                    return;
                }
                var dbo = db.db("mongo").collection("inquireDatas");
                dbo.insertOne(fields, function (err, result) {
                    if (err) {
                        console.log("错误");
                        res.send({
                            "err": err
                        });
                    }
                    res.send({
                        "data": fields
                    });
                })
            })

        });
    })
})
app.get("/particulars", function (req, res) {
    var obj = req.query;
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("inquireDatas");
        dbo.find({
            "_id": ObjectId(obj._id)
        }).limit(1).toArray(function (err, items) {
            if (err) {
                res.send({
                    "err": err
                })
                return;
            }
            if (items.length) {
                res.send({
                    "data": items
                })
            }
            db.close();
        })
    })
})
app.get("/delete", function (req, res) {
    var i = req.query.i;
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("inquireDatas");
        dbo.find({"use_id":req.query.use_id}).limit(10).skip(i * 10).toArray(function (err, items) {
            if (err) {
                res.send({
                    "err": err
                })
                return
            }
            if (items.length) {
                res.send({
                    "data": items
                })
            } else {
                res.send({
                    "err": "空"
                })
            }
            db.close();
        })
    })
})

app.get("/searchcontent", function (req, res) {
    req.query.vle = eval("/" + req.query.vle + "/");
    databaseQuery("mongo", "inquireDatas", {
        $or: [{
            "vle": req.query.vle
        }, {
            "name": req.query.vle
        }]
    }, req, res);
})

app.get("/inquireData", function (req, res) {
    req.query.vle = eval("/^" + req.query.vle + "/");
    databaseQuery("mongo", "inquireDatas", req.query, req, res)
})

app.post("/success", jsonParser, function (req, res) {
    var obj = req.body;
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        console.log(obj);
        var dbo = db.db("mongo").collection("inquireDatas");
        dbo.findAndRemove({
            "_id": ObjectId(obj._id)
        }, {
            safe: true
        }, function (err, sctd) {
            if (err) {
                res.send({
                    "err": "未知错误"
                })
            }
            console.log(sctd);
            res.send({
                "name": "成功"
            });
            db.close();
        })
    })
})

app.post("/", jsonParser, function (req, res) {
    var obj = req.body,
        login = {},
        boole = {};
    if (req.session.login != undefined) {
        var judge = obj.hasOwnProperty("logOut");
        if (judge) {
            req.session.login = undefined;
            boole.registered = 1;
            res.end(JSON.stringify(boole));
        } else {
            boole.registered = 1;
            boole.name = req.session.login.name;
            res.end(JSON.stringify(boole))
        }
    } else {
        if (!obj.posd) {
            return;
        }
        MongoClient.connect(url, function (err, db) {
            if (err) {
                return;
            }
            var dbo = db.db("mongo").collection("student");
            dbo.find({
                "enterPassword": crypto.createHash("md5").update(crypto.createHash("md5").update(obj.posd).digest("base64")).digest("base32"),
                $or: [{
                    "number": obj.number
                }, {
                    "name": obj.number
                }]
            }).toArray(function (err, items) {
                if (err) {
                    return;
                }
                if (items.length) {
                    login = items[0];
                    req.session.login = login;
                    boole.name = (items[0].name);
                    boole.id = (items[0]._id);
                    boole.registered = 1;
                } else {
                    boole.registered = 0;
                }
                res.end(JSON.stringify(boole));
                db.close();
            })
        })
    }
});
app.post("/guessWhat", jsonParser, function (req, res) {
    var obj = req.body,
        boole = "";
    obj.vle = eval("/" + obj.vle + "/i");
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("inquireDatas");
        dbo.find({
            $or: [{
                "vle": obj.vle
            }, {
                "name": obj.vle
            }]
        }).toArray(function (err, items) {
            if (err) {
                router;
            }
            if (items.length) {
                boole = items;
                res.end(JSON.stringify(boole));
                db.close();
            } else {
                dbo.find({
                    vle: /潮流/i
                }).toArray(function (err, itemsa) {
                    if (itemsa.length) {
                        boole = itemsa;
                        res.end(JSON.stringify(boole));
                    } else {
                        res.end();
                        router;
                    }
                })
            }
        })
    })
})
app.post("/datalet", function (req, res) {
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("inquireDatas");
        dbo.find({}).toArray(function (err, items) {
            if (err) {
                res.send({
                    "err": err
                })
            }
            res.send({
                "dataLen": items.length
            });
        })
    })
})
app.post("/personalCenter.html", jsonParser, function (req, res) {
    var obj = req.body,
        database = "",
        judgeDatabase = obj.hasOwnProperty("vle");
    if (!judgeDatabase) {
        if (req.session.login != undefined) {
            if (obj.name == req.session.login.name) {
                database = "student";
            } else {
                res.end(JSON.stringify({
                    "noThing": "0"
                }));
                return;
            }
        } else {
            res.end(JSON.stringify({
                "noThing": "0"
            }));
            return;
        }
    } else {
        obj.vle = eval("/^" + obj.vle + "/");
        database = "inquireDatas";
    }
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection(database);
        dbo.find(obj).toArray(function (err, items) {
            if (items.length) {
                items[0].enterPassword = null;
                res.end(JSON.stringify(items));
                db.close();
            } else {
                res.end(JSON.stringify({
                    "noThing": "0"
                }));
                db.close();
                return;
            }
        })
    })
})

app.post("/retrievePassword.html", jsonParser, function (req, res) {
    var obj = req.body,
        boole = {};
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("student");
        dbo.find({
            "number": obj.number
        }).toArray(function (err, items) {
            if(err){
                return;
            }
            if (items.length) {
                boole.registered = 1;
            } else {
                boole.registered = 0;
            }
            res.end(JSON.stringify(boole));
            db.close();
        })
        // dbo.update({"number":obj.number},{$set:{"enterPassword":obj.posd}},function(err){
        //     if(err){
        //         res.end(JSON.stringify(boole));
        //         return;
        //     }
        //     console.log(boole);
        //     res.end(JSON.stringify(boole));
        //     db.close();
        // });
    })
})

app.post("/register.html", jsonParser, function (req, res) {
    var obj = req.body,
        boole = "";
    MongoClient.connect(url, function (err, db) {
        if (err) {
            return;
        }
        var dbo = db.db("mongo").collection("student");
        if (obj.bool == 1) {
            dbo.find({
                "number": obj.number
            }).toArray(function (err, items) {
                if (err) {
                    return;
                }
                if (items.length) {
                    boole = 1;
                } else {
                    boole = 0;
                }
                res.end(JSON.stringify({
                    "registered": boole
                }));
                db.close();
            })
        } else {
            dbo.find({
                $or: [{
                    "name": obj.name
                }, {
                    "number": obj.name
                }]
            }).toArray(function (err, items) {
                if (err) {
                    return
                }
                if (items.length) {
                    boole = 2;
                } else {
                    boole = 1;
                    dbo.insertOne({
                        "name": obj.name,
                        "enterPassword": crypto.createHash("md5").update(crypto.createHash("md5").update(obj.enterPassword).digest("base64")).digest("base32"),
                        "number": obj.number,
                        "gender": obj.gender
                    }, function (err, res) {
                        if (err) {
                            return;
                        }
                    });
                }
                res.end(JSON.stringify({
                    "registered": boole
                }));
                db.close();
            })
        }
    })
})
app.post("/logoName", jsonParser, admin_logo.logo);
app.post("/use_platform",jsonParser,admin_logo.useLo);
app.get("/use_quit",jsonParser,admin_logo.useQuit);
// 处理加入购物车
app.post("/addShopping",jsonParser,commodity.shopping);
// 处理购物数据请求
app.post("/shoppingTr",jsonParser,commodity.shoppingTr);
// 处理购物车删除商品
app.post("/remove_commod",jsonParser,commodity.remove_comm);

app.use(express.static("./staticPage"));
app.use(express.static("./uploads"));

app.get("/ejs", router.showIndex);
app.get("/up", router.showUp);
app.get("/:albumName", router.showAlbum);


app.post("/up", router.doPost);

app.use(function (req, res) {
    res.render("err");
});
app.listen(3000);
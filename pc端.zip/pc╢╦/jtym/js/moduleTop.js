Vue.component("shortcut", {
    props: ['use_data'],
    template: ` <div class="shortcut">
    <div class="headIntroduced">
        <ul class="site-nav-bd-l">
            <li @mouseenter="according(0)" @mouseleave="hideIndividual(0)">
                <a href="./personalCenter.html" class="backgr">Hi,{{use_data.name}}</a>
                <div class="individualResume" v-if="personalCenterReveal">
                    <div class="image">
                        <img :src="defaultImage">
                    </div>
                    <div class="andPersonalCenter">
                        <span><a href="#">个人中心</a></span>|
                        <span @click="replacement"><a href="#">退出</a></span>
                    </div>
                    <div class="condition">
                        <p>个人活跃度：{{liveness}}</p>
                        <p>普通会员</p>
                    </div>
                </div>
            </li>
            <li @mouseenter="according(1)" @mouseleave="hideIndividual(1)">
                <a href="#javascript" class="backgr">
                    <span class="iconfont">&#xe608;</span> 消息
                </a>
                <div class="personalNews" v-if="personalNews">
                    <h3 class="newsLogo">未读新消息</h3>
                    <div class="newsContent">
                        <ul v-if="newsDetails">
                            <li></li>
                        </ul>
                        <div v-else="newsDetails" class="newsDetails">
                            没有新消息了
                        </div>
                        <img src="./img/myzd.jpg">
                        <button class="historyNews">查看历史消息</button>
                    </div>
                    <div class="newsBase">
                        <i>*</i>
                        <span>全部消息</span>
                    </div>
                </div>
            </li>
        </ul>
        <ul class="site-nav-bd-r">
            <li v-for="(item, index) in compositeData" :key="index"><a :href="item.skip">{{item.name}}</a>
            </li>
        </ul>
    </div>
</div>`,
data: function() {
    return {
        personalCenterReveal: false,
        defaultImage: "./img/mrtp.jpg",
        liveness: "423",
        personalNews:false,
        newsDetails:false,
        compositeData: [{
            name: "首页",
            skip: "/"
        }, {
            name: "我的订单",
            skip: "./personalCenter.html"
        }, {
            name: "收藏夹",
            skip: "#javascript"
        }, {
            name: "联系客服",
            skip: "#javascript"
        }, {
            name: "lv会员",
            skip: "#javascript"
        }, {
            name: "网站导航",
            skip: "#javascript"
        }],
    }
},
methods: {
    according: function (index) {
        if (!index) {
            this.personalCenterReveal = true;
        } else {
            this.personalNews = true;
        }
    },hideIndividual: function (index) {
        if (!index) {
            this.personalCenterReveal = false;
        } else {
            this.personalNews = false;
        }
    },
   
    replacement: function () {

    },
}
})
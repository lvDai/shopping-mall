;
(function () {
    new Vue({
        el: "#app",
        data: {
            akse: 0,
            number: '',
            smsVerification: '',
            username: '',
            enterPassword: '',
            enterAgain: '',
            reminder: '',
            gender: '男',
            judge: false,
            code: false,
            bool: false,
            reminderbool: false,
            boolnext: true,
            registeredSuccessfully: false,
            registrationProcedure: ['设置用户名', '填写账号信息', '注册成功'],
            SMS: "发送短信验证",
            ending: ['关于我们', '合作伙伴', '联系客服', '开发平台', '联系我们', '广告服务', '友情链接'],
            registered: "",
            mistakeMessage: "",
            estimateEstimate: false,
            shadeTier : false,
            authCode : "",
        },
        methods: {
            switchover: function (e) {
                if (this.number == "") {
                    this.judge = true;
                    return;
                }
                if (this.number.length != 11) {
                    this.judge = false;
                    this.estimateEstimate = true;
                    this.mistakeMessage = "手机号码长度不对";
                    return;
                }
                e = e || window.event;
                this.estimateEstimate = false;
                e.target.setAttribute("disabled", "disabled");
                let i = 60,
                    thisA = this,
                    sms = '重新发送短信',
                    verificationArr = ["1","2","3","4","5","6","7","8","9","0","a","b","c","d","e","f","j","k","h","l","m","l","n"];
                clearInterval(s);
                this.bool = true;
                var s = setInterval(function () {
                    i--;
                    thisA.SMS = sms + "(" + i + "s)";
                    if (!i) {
                        clearInterval(s);
                        thisA.SMS = '重新发送短信';
                        e.target.disabled = false;
                    }
                }, 1000);
                for(var j = 0;j < 4;j++){
                  this.authCode += verificationArr[parseInt(Math.random()*verificationArr.length)];
                }   
                alert("验证码是："+this.authCode);
            },
            authentication: function () {
                if (this.smsVerification == "" && this.number == "") {
                    this.judge = true;
                    return;
                }
                if (this.smsVerification == '') {
                    this.judge = false;
                    this.code = true;
                    return;
                }
                if(this.authCode != this.smsVerification){
                    this.estimateEstimate = true;
                    this.mistakeMessage = "验证码错误";
                    return;
                }
                if (this.smsVerification && this.number && this.bool) {
                    this.bool = false;
                    var thisA = this,
                        obj = {};
                    obj.number = this.number;
                    obj.bool = "1";
                    this.$http.post("#", obj).then(function (response) {
                        var eaj = response.data;
                        if (eaj.registered) {
                            thisA.estimateEstimate = true;
                            thisA.mistakeMessage = "此手机号码已注册";
                        } else {
                            thisA.boolnext = false;
                            thisA.akse = 1;
                        }
                    })
                    thisA.bool = true;
                }
            },
            submitData: function () {
                if (this.username && this.enterPassword && this.enterAgain) {
                    if (this.username.length < 2) {
                        this.reminderbool = true;
                        this.reminder = "用户名长度要大于等于二";
                        return;
                    }
                    if (this.enterPassword.length < 6) {
                        this.reminderbool = true;
                        this.reminder = "密码长度要大于等于六";
                        return
                    }
                    var obj = {
                        name: this.username,
                        enterPassword: this.enterPassword,
                        number: this.number,
                        gender:this.gender,
                        bool: "0"
                    };
                    var thisA = this;
                    if (thisA.enterPassword != thisA.enterAgain) {
                        thisA.reminderbool = true;
                        thisA.reminder = "俩次密码不一样";
                        return;
                    }
                    thisA.shadeTier = true;
                    this.$http.post("#", obj).then(function (response) {
                        if (response.data.registered=="1") {
                            thisA.akse = 2;
                            thisA.registeredSuccessfully = true;
                        } else {
                            thisA.reminderbool = true;
                            thisA.reminder = "用户名已存在";
                        }
                    })
                    thisA.shadeTier = false;
                }
            }
        }
    })
})();
new Vue({
    el : "#app",
    data : {
        bshwa : '',
        searchDetails:'',
        
    },
    methods: {
        LoadPerform: function () {
            var thisA = this;
            this.bshwa = localStorage.name || "";
            this.$http.post('./personalCenter.html',{name:thisA.bshwa}).then(function (response) {
                var reception = response.data[0];
                console.log(reception);
                if (response.data.noThing == "0") {
                    window.location.href = '/';
                } else {
                    thisA.bshwa = reception.name;
                }
            })
            if (this.bshwa == "") {
                window.location.href = '/';
            }
        },
    },
    mounted () {
        this.LoadPerform();
    }
})
;
(function () {
    new Vue({
        el: '#app',
        data: {
            bshwa: "",
            personalCenterReveal: false,
            personalNews: false,
            newsDetails: false,
            defaultImage: "./img/mrtp.jpg",
            liveness: "423",
            compositeData: [{
                name: "首页",
                skip: "/"
            }, {
                name: "我的订单",
                skip: "./personalCenter.html"
            }, {
                name: "收藏夹",
                skip: "#javascript"
            }, {
                name: "联系客服",
                skip: "#javascript"
            }, {
                name: "lv会员",
                skip: "#javascript"
            }, {
                name: "网站导航",
                skip: "#javascript"
            }],
            mtNavSafety: ["修改密码", "手机绑定", "密保设置", "其他"],
            mtNavData: ["个人资料", "修改头像、名称", "其他设置"],
            mtNavNBinding: ["QQ绑定", "微信绑定", "微博绑定", "其他"],
            content_l: [{
                title: "订单中心",
                data: ["我的购物车", "我的订单", "评价晒单"],
                skip: ["./shopping.html", "./personalCenter.html", "javascript:;"]
            }, {
                title: "我的钱包",
                data: ["优惠券", "红包", "支付方式", "更多>"],
                skip: ["javascript:;", "javascript:;", "javascript:;", "javascript:;"]
            }, {
                title: "我的关注",
                data: ["关注商品", "关注店铺", "内容收藏"],
                skip: ["javascript:;", "javascript:;", "javascript:;"]
            }],
            whichNumber: "",
            searchData: "",
            searchHint: [],
            saveData: "",
            hintBool: true,
            ajax: function () {
                var obj = {
                    vle: this.searchData
                };
                this.$http.post("#", obj).then(function (response) {
                    var reception = response.data;
                    if (reception.noThing == "0") {
                        this.searchHint = "";
                        return;
                    }
                    this.saveData = reception;
                    if (reception.length > 6) {
                        for (var i = 0; i > 6; i++) {
                            this.searchHint[i] = reception[i];
                        }
                        return;
                    }
                    this.searchHint = reception;
                })
            },
            timer: null,
        },
        methods: {
            according: function (index) {
                if (!index) {
                    this.personalCenterReveal = true;
                } else {
                    this.personalNews = true;
                }
            },
            hideIndividual: function (index) {
                if (!index) {
                    this.personalCenterReveal = false;
                } else {
                    this.personalNews = false;
                }
            },
            replacement: function () {

            },
            LoadPerform: function () {
                var thisA = this;
                this.bshwa = localStorage.name || "";
                this.$http.post('#',{name:thisA.bshwa}).then(function (response) {
                    var reception = response.data[0];
                    if (response.data.noThing == "0") {
                        window.location.href = '/';
                    } else {
                        thisA.bshwa = reception.name;
                    }
                })
                if (this.bshwa == "") {
                    window.location.href = '/';
                }
            },
            searchHintBool: function (index) {
                if (index) {
                    this.hintBool = true;
                    return;
                } else {
                    var thisA = this;
                    setTimeout(function () {
                        thisA.hintBool = false;
                    }, 120);
                }
            },
            obtainVle: function (index) {
                window.location.href=`./searchcontent.html?vle=${this.searchHint[index].name}`
                this.hintBool = false;
            },
            findWhat: function () {
                console.log("11111");
            }
        },
        mounted: function () {
            this.LoadPerform();
        },
        watch: {
            searchData: function (value) {
                if (this.searchData.length == 0 || this.searchData.match(/^\s+$/g)) {
                    clearTimeout(this.timer);
                    this.searchHint.length = 0;
                    return;
                }
                var thisA = this;
                clearTimeout(this.timer);
                this.timer = setTimeout(function () {
                    thisA.ajax.apply(thisA);
                }, 300);
            }
        }
    })
}())
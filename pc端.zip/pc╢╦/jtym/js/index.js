;
(function () {
    Vue.use(VueLazyload);
    var danoas = "";
    var vm = new Vue({
        el: '#app',
        data: {
            cancelRegister: true,
            use_name:(localStorage.name) ? (localStorage.name.substr(0, 4) + ((localStorage.name.length > 4) ? "..." : "")) : "你好,",
            items: [{
                    name: "账号",
                    type: "text",
                    placeholder: "请输入用户名/手机号",
                    Verification: false,
                    bshwa: localStorage.name || "",
                    wrongInformation: ""
                },
                {
                    name: "密码",
                    type: "password",
                    placeholder: "请输入密码",
                    Verification: false,
                    bshwa: "",
                    wrongInformation: ""
                }
            ],
            hotwords: ["华为特惠", "潮流T恤", "短裤", "新款男鞋", "时尚女包", "100减50", "男士外套"],
            compositeData: [{
                name: "首页",
                skip: "/"
            }, {
                name: "我的订单",
                skip: "./personalCenter.html"
            }, {
                name: "收藏夹",
                skip: "#javascript"
            }, {
                name: "联系客服",
                skip: "#javascript"
            }, {
                name: "lv会员",
                skip: "#javascript"
            }, {
                name: "网站导航",
                skip: "#javascript"
            }],
            clearfixR: ["秒杀", "优惠券", "电器城", "闪购", "转卖"],
            contentBoxL: [
                ["男装", "女装", "童装", "其他"],
                ["家用电器", "家具", "家饰", "家纺"],
                ["手机", "数码", "电脑", "办公"],
                ["美妆", "洗护", "保健品", "宠物"],
                ["男鞋", "女鞋", "户外", "运动健身"],
                ["母婴", "玩具乐器", "艺术", "书籍"],
                ["食品", "酒类", "生鲜", "特产"],
                ["娱乐", "电子书", "工具", "动漫"],
                ["学习", "影视", "眼镜", "钟表"],
                ["珠宝", "首饰", "箱包", "礼品鲜花"],
                ["房产", "汽车", "工具", "清洗保养"],
                ["农资绿植", "生活", "工业", "装修"],
            ],
            contentDa: [
                [{
                    name: "男装",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装", "设计师/潮牌", "唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "女装",
                    data: ["当季热卖", "新品推荐", "商场同款", "时尚套装", "连衣裙", "套装裙", "半身裙", "T恤衬衫", "雪纺衫", "短外套", "卫衣", "针织衫", "小西装", "风衣", "休闲裤", "牛仔裤", "短裤", "大码女装", "中老年", "女装打底裤", "正装裤", "打底衫", "毛衣", "马甲", "吊带/背心", "毛呢大衣", "羽绒服", "仿皮皮衣", "真皮皮衣", "羊绒衫", "棉服", "皮草加绒裤", "旗袍/唐装礼服", "婚纱设计师/潮牌"],
                }, {
                    name: "童装",
                    data: ["套装", "卫衣", "裤子", "外套/大衣", "毛衣/针织衫", "衬衫", "户外/运动服", "T恤", "裙子", "亲子装", "礼服/演出服", "羽绒服", "棉服", "内衣裤", "配饰", "家居服", "马甲", "袜子", "民族服装", "婴儿礼盒", "连体衣/爬服", "运动鞋", "靴子", "帆布鞋", "皮鞋", "棉鞋", "凉鞋", "拖鞋"],
                }],
                [{
                    name: "家用电器",
                    data: ["生活电器", "厨房电器", "个人护理", "电视机", "空调", "洗衣机", "冰箱", "空气净化器", "扫地机器人", "吸尘器", "取暖器", "烤箱", "豆浆机", "榨汁料理", "电饭煲", "吹风机", "足浴盆", "剃须刀", "卷发器", "按摩器材", "冬季火锅", "电暖桌", "电热毯", "加湿器", "暖风机"],
                }, {
                    name: "家具",
                    data: ["客厅", "卧室", "餐厅", "书房", "儿童", "储物", "商业", "办公", "阳台", "户外", "电脑桌", "电视柜", "茶几", "办公柜", "进口/原创沙发", "床", "床垫", "餐桌", "衣柜", "书架", "鞋柜", "置物架", "电脑椅", "晾衣架", "儿童床", "儿童桌椅", "红木"],
                }, {
                    name: "家饰",
                    data: ["窗帘", "地毯", "沙发垫", "十字绣", "桌布", "地垫", "抱枕", "坐垫", "飘窗垫", "门帘", "缝纫机", "洗衣机罩", "卷帘", "珠帘", "沙发巾", "靠垫", "空调罩", "餐桌布", "门垫", "浴室防滑垫", "茶几桌布", "桌垫", "装饰画", "摆件", "照片墙", "相框", "墙贴", "花瓶", "壁纸", "挂钟", "仿真花", "油画", "客厅装饰画", "玻璃贴纸", "香炉", "玻璃花瓶", "相框挂墙", "数字油画", "假花", "画框", "干花"],
                }, {
                    name: "家纺",
                    data: ["夏凉被", "草席", "床褥", "U型枕", "蚊帐", "凉席", "天丝套件", "贡缎套件", "提花套件", "婚庆套件", "儿童套件", "空调被", "儿童床品", "麻将凉席", "四件套", "毛巾被", "记忆枕", "老粗布", "床垫", "婚庆床品", "床笠", "蒙古包蚊帐", "空调毯", "枕头", "宫廷蚊帐", "牛皮席", "冰丝席", "竹席", "藤席"],
                }],
                [{
                    name: "手机",
                    data: ["手机", "游戏手机", "老人机", "对讲机", "以旧换新", "手机维修", "手机壳", "贴膜", "手机存储卡", "数据线", "充电器", "手机耳机", "创意配件", "手机饰品", "手机电池", "苹果", "周边", "移动电源", "蓝牙耳机", "手机支架", "车载配件", "拍照配件"],
                }, {
                    name: "数码",
                    data: ["游戏主机", "数码精选", "手机壳套", "苹果手机壳", "surface平板电脑", "苹果/Apple", "iPad Pro", "电脑主机", "数码相机", "电玩动漫", "单反相机", "华为", "MateBook", "IPAD", "mini4", "游戏主机", "鼠标键盘", "无人机", "二手数码", "二手手机", "二手笔记本", "二手平板电脑"],
                }, {
                    name: "电脑",
                    data: ["笔记本", "游戏本", "平板电脑", "平板电脑配件", "台式机", "一体机", "服务器/工作站", "笔记本配件"],
                }, {
                    name: "办公",
                    data: ["投影机", "投影配件", "多功能一体机", "打印机", "传真设备", "验钞/点钞机", "扫描设备", "复合机", "碎纸机", "考勤门禁", "收银机", "会议音频视频", "保险柜", "装订/封装", "机安防监控", "办公家具", "白板"],
                }],
                [{
                    name: "美妆",
                    data: ["礼盒", "美白", "防晒", " 面膜", "洁面", " 爽肤水", "精华", "眼霜", "乳液/面霜", "卸妆", "T区护理", "润唇膏", "隔离", "遮瑕", "气垫", " BB粉", "底腮红", " 口红/唇膏", "唇釉/唇彩", "睫毛膏", "眼影", "眼线", "眉笔/眉粉", "散粉", "美甲", "女士香水", "男士香水", "彩妆工具", "男士彩妆", "彩妆套装", "控油", "洁面", "乳液/面霜", "剃须"],
                }, {
                    name: "洗护",
                    data: ["洗发水", "护发素", " 发膜/精油", "造型", "染发烫发", "假发", "美发工具", "洗护套装", "牙膏", "牙粉", "牙贴", "牙刷", "牙线", "漱口水", "口喷", "假牙", "清洁套装", "花露水", "沐浴露", "香皂", "洗手液", " 护手霜", "浴盐", "润肤精油", "美颈", "美胸", "纤体塑形", "手膜/足膜", "男士洗液", "走珠/止汗", "露脱毛刀/膏", "套装"],
                }, {
                    name: "保健品",
                    data: ["B族维生素", "葡萄籽", "辅酶Q10", "消化酶", "软骨素", "维生素C", "钙", "大豆异黄酮", "益生菌", "鱼油", "氨基葡萄糖", "葡萄籽", "生物素", "玛咖（玛卡）", "酵素", "螺旋藻", "胶原蛋白", "月见草油", "DHA", "蔓越莓", "左旋肉碱", "褪黑素", "锯棕榈", "阿胶", "蜂蜜/蜂产品", "枸杞", "燕窝", "冬虫夏", "草人参/西洋参", "三七", "鹿茸", "雪蛤", "青钱柳", "石斛/枫", "斗灵芝/孢子粉", "当归", "养生茶饮", "药食同源"],
                }, {
                    name: "宠物",
                    data: ["狗粮", "狗罐头", "狗零食", "狗厕所", "尿垫", "猫粮", "猫罐头", "猫零食", "猫砂", "猫砂盆", "猫狗窝", "食具", "水具", "医疗保健", "宠物玩具", "宠物鞋服", "洗护美容", "宠物牵引", "小宠用品", "水族世界", "鱼缸/水族箱", "鱼粮/饲料", "水族活体"],
                }],
                [{
                    name: "男鞋",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "女鞋",
                    data: ["新品推荐", "单鞋", "休闲鞋", "帆布鞋", "妈妈鞋", "布鞋/绣花鞋", "女靴", "踝靴", "马丁靴", "雪地靴", "雨鞋/雨靴", "高跟鞋", "凉鞋", "拖鞋/人字拖", "鱼嘴鞋", "内增高", "坡跟鞋", "防水台", "松糕鞋", "鞋配件"],
                }, {
                    name: "户外",
                    data: ["户外风衣", "徒步鞋", "T恤", "冲锋衣裤", "速干衣裤", "越野跑鞋", "滑雪服", "羽绒服/棉服", "休闲衣裤", "抓绒衣裤", "溯溪鞋", "沙滩/凉拖", "休闲鞋", "软壳衣裤", "功能内衣", "军迷服饰", "登山鞋", "工装鞋", "户外袜", "背包", "帐篷/垫子", "望远镜", "烧烤用具", "便携桌椅床", "野餐用品", "睡袋/吊床", "救援装备", "户外照明", "旅行装备", "户外工具", "户外仪表", "登山攀岩", "极限户外", "冲浪潜水", "滑雪装备", "钓竿", "鱼线", "浮漂", "鱼饵", "钓鱼配件", "渔具包", "钓箱钓椅", "鱼线轮", "钓鱼灯", "辅助装备"],
                }, {
                    name: "运动健身",
                    data: ["女士泳衣", "比基尼", "男士泳衣", "泳镜", "游泳圈", "游泳包", "防水包", "泳帽", "游泳配件", "跑步机", "动感单车", "健身车", "椭圆机", "综合训器", "划船机", "甩脂机", "倒立机", "踏步机", "哑铃", "仰卧板/收腹机", "瑜伽用品", "舞蹈用品", "运动护具", "健腹轮", "拉力器/臂力器", "跳绳", "引体向上器"],
                }],
                [{
                    name: "母婴",
                    data: ["1段", "2段", "3段", "4段", "孕妈奶粉", "特殊配方奶粉", "有机奶粉", "米粉/菜粉", "面条/粥", "果泥/果汁", "益生菌/初乳", "DHA", "钙铁锌/维生素", "清火/开胃", "宝宝零食", "NB", "S", "M", "L", "XL", "XXL", "拉拉裤", "成人尿裤", "婴儿湿巾", "奶瓶", "奶嘴", "吸奶器", "暖奶消毒", "辅食料理机", "牙胶安抚", "食物存储", "儿童餐具", " 水壶/水杯", "围兜/防溅衣"],
                }, {
                    name: "玩具乐器",
                    data: ["全新钢琴", "二手钢琴", "电钢琴", "电子琴", "萨克斯", "尤克里里", "架子鼓", "小提琴", "口琴", "手卷钢琴", "古筝", "古琴", "二胡", "葫芦丝", "陶笛", "琵琶", "笛子", "非洲鼓", "贝斯", "调音器", "节拍器", "电吉他", "电箱吉他", "乐器音箱", "电子鼓", "手风琴", "大提琴", "合成器", "适用年龄", "益智玩具", "橡皮泥", "芭比娃娃", "绘画/DIY", "积木拼装", "遥控/电动", "毛绒玩具", "娃娃玩具", "动漫玩具", "模型玩具", "创意减压"],
                }, {
                    name: "艺术",
                    data: ["油画", "版画", "水墨画", "书法", "雕塑", "艺术画册", "艺术衍生品", "绘画", "摄影", "音乐", "书法", "连环画", "设计", "建筑艺术", "艺术史", "影视"],
                }, {
                    name: "书籍",
                    data: ["小说", "散文随笔", "青春文学", "传记", "动漫", "悬疑推理", "科幻", "武侠", "世界名著", "历史", "心理学", "政治军事", "传统文化", "哲学宗教", "社会科学", "法律文化", "党政专区", "管理"," 金融", "经济市场", "营销", "领导力", "股票投资", "励志与成功", "自我完善"],
                }],
                [{
                    name: "食品",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "酒类",
                    data: [],
                }, {
                    name: "生鲜",
                    data: [],
                }, {
                    name: "特产",
                    data: [],
                }],
                [{
                    name: "娱乐",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "电子书",
                    data: [],
                }, {
                    name: "工具",
                    data: [],
                }, {
                    name: "动漫",
                    data: [],
                }],
                [{
                    name: "学习",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "影视",
                    data: [],
                }, {
                    name: "眼镜",
                    data: [],
                }, {
                    name: "钟表",
                    data: [],
                }],
                [{
                    name: "珠宝",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "首饰",
                    data: [],
                }, {
                    name: "箱包",
                    data: [],
                }, {
                    name: "礼品鲜花",
                    data: [],
                }],
                [{
                    name: "房产",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "汽车",
                    data: [],
                }, {
                    name: "工具",
                    data: [],
                }, {
                    name: "清洗保养",
                    data: [],
                }],
                [{
                    name: "农资绿植",
                    data: ["当季热卖", "新品推荐", "T恤", "牛仔裤", "休闲裤", "衬衫", "短裤", "POLO衫羽绒服", "棉服", "真皮皮衣", "夹克", "卫衣", "毛呢大衣", "大码男装", "西服套装", "仿皮皮衣", "风衣", "针织衫", "马甲/背心", "羊毛衫", "羊绒衫", "西服", "西裤", "卫裤/运动裤", "工装设计师/潮牌唐装/中山装", "中老年男装", "加绒裤"],
                }, {
                    name: "生活",
                    data: [],
                }, {
                    name: "工业",
                    data: [],
                }, {
                    name: "装修",
                    data: [],
                }],
            ],
            contentDaTa: [],
            slideshow: ["图片1", "图片2", "图片3", "图片4"],
            servicEntry: [{
                print: "iconfont icon-huafei",
                name: "话费"
            }, {
                print: "iconfont icon-jipiao",
                name: "机票"
            }, {
                print: "iconfont icon-jiudian",
                name: "酒店"
            }, {
                print: "iconfont icon-youxi",
                name: "游戏"
            }, {
                print: "iconfont icon-huochepiao",
                name: "火车票"
            }, {
                print: "iconfont icon-lvhang",
                name: "旅行"
            }, {
                print: "iconfont icon-74",
                name: "电影"
            }, {
                print: "iconfont icon-shuidianmei",
                name: "水电煤"
            }, {
                print: "iconfont icon-caipiao",
                name: "彩票"
            }],
            guessWhat: [],
            twoDimension: false,
            hjia: false,
            scroll: '',
            loginSuccessfully: true,
            loading: false,
            WrongPassword: false,
            registerReveal: true,
            defaultImage: './img/mrtp.jpg',
            liveness: '423',
            personalCenterReveal: false,
            newsDetails: false,
            personalNews: false,
            enterAfterwards: false,
            searchDetails: "",
            searchHint: [],
            saveData: "",
            proExhi: true,
            rotation: {},
            DisplayIt: "点击隐藏",
            hintBool: false,
            grabbleReg: false,
            placeData: "潮流T恤",
            Switching: {},
            i: 0,
            eliminate: "",
            initDa: "",
            contentDashow: '',
            rocketsBool:false,
            rocketsSet:"",
            indicators: {
                "height": "8px",
                "border-radius": "50%",
                "margin-top": "-3px",
            },
            PositionC: {
                "left": "0"
            },
            jildanq:[],
            ajax: function (idnex) {
                this.$http.get("/inquireData?vle=" + this.searchDetails).then(function (response) {
                    danoas= response.data;
                    var reception = response.data;
                    if (reception.noThing == "0") {
                        this.hintBool = false;
                        return;
                    } else {
                        this.hintBool = true;
                        this.saveData = reception;
                        if (reception.length > idnex) {
                            for (var i = 0; i > idnex; i++) {
                                this.searchHint[i] = reception[i];
                                this.searchHint[i].name = this.searchHint[i].name.replace(new RegExp(`${this.searchDetails}`, "g"), function ($) {
                                    return `<span class="key">${$}</span>`;
                                });
                            }
                            return;
                        }
                        this.searchHint = reception;
                        for (let i = 0; i < this.searchHint.length; i++) {
                            this.searchHint[i].name = this.searchHint[i].name.replace(new RegExp(`${this.searchDetails}`, "g"), function ($) {
                                return `<span class="key">${$}</span>`;
                            });
                        }
                    }
                })
            }
        },
        methods: {
            presentRegister: function () {
                this.cancelRegister = !this.cancelRegister;
            },
            //登录之前判断
            theVerification: function (i, e) {
                e = e || window.event;
                j = i ? 6 : 2;
                if (!e.target.value.length) {
                    this.items[i].Verification = true;
                    this.items[i].wrongInformation = this.items[i].name + "不能为空";
                } else if (e.target.value.length < j) {
                    this.items[i].Verification = true;
                    this.items[i].wrongInformation = this.items[i].name + "长度不能小于" + j + "位";
                }
            },
            getFocus: function (i) {
                this.items[i].Verification = false;
            },
            showHidden: function (bool) {
                if (bool) {
                    this.twoDimension = true;
                } else {
                    this.twoDimension = false;
                }
            },
            //小火箭
            menu: function () {
                this.scroll = document.body.scrollTop || document.documentElement.scrollTop;
                (this.scroll >= 10) ? (this.hjia = true) : (this.hjia = false);
                (this.scroll >= 200) ? (this.grabbleReg = true) : (this.grabbleReg = false);
            },
            rockeA: function () {
                var thisA = this
                var s = setInterval(function () {
                    if (thisA.scroll > 0) {
                        thisA.scroll = thisA.scroll - 20;
                        window.scrollTo(0, thisA.scroll);
                    } else {
                        clearTimeout(s);
                        return;
                    }
                }, 10)
                return;
            },
            registerShow: function () {
                this.cancelRegister = true;
            },
             //登录判断
            interaction: function () {
                if(!this.items[0].bshwa){
                    this.items[0].Verification = true;
                    this.items[0].wrongInformation = "账号不能为空";
                    return;
                }else if(!this.items[1].bshwa) {
                    this.items[1].Verification = true;
                    this.items[1].wrongInformation = "密码不能为空";
                    return;
                }
                if (!this.items[0].Verification && !this.items[1].Verification) {
                    this.loading = true;
                    var thisA = this,
                        obj = {
                            number: this.items[0].bshwa,
                            posd: this.items[1].bshwa
                        };
                    this.$http.post('#', obj).then(function (response) {
                        thisA.loading = false;
                        var reception = response.data;
                        if (reception.registered) {
                            thisA.enterAfterwards = true;
                            thisA.cancelRegister = false;
                            thisA.loginSuccessfully = false;
                            thisA.registerReveal = false;
                            thisA.items[0].bshwa = reception.name;
                            localStorage.name = reception.name;
                            localStorage.id = reception.id;
                        } else {
                            thisA.WrongPassword = true;
                        }
                    })
                }
            },
            personalCenter: function () {

            },
            according: function (index) {
                if (!this.enterAfterwards) {
                    return;
                }
                if (!index) {
                    this.personalCenterReveal = true;
                } else {
                    this.personalNews = true;
                }
            },
            hideIndividual: function (index) {
                if (!this.enterAfterwards) {
                    return;
                }
                if (!index) {
                    this.personalCenterReveal = false;
                } else {
                    this.personalNews = false;
                }
            },
            replacement: function () {
                this.loginSuccessfully = true;
                this.personalCenterReveal = false;
                this.enterAfterwards = false;
                this.registerReveal = true;
            },
            nextTextbox: function (index) {
                var page = document.getElementsByClassName("page")[0],
                    input = page.getElementsByTagName("input");
                if (!index) {
                    input[index + 1].focus();
                } else {
                    this.interaction();
                }
            },
            //初始化区
            init: function () {
                var thisA = this;
                this.$http.post("#").then(function (response) {
                    thisA.loading = false;
                    var reception = response.data;
                    if (reception.registered) {
                        thisA.enterAfterwards = true;
                        thisA.cancelRegister = false;
                        thisA.loginSuccessfully = false;
                        thisA.registerReveal = false;
                        thisA.items[0].bshwa = reception.name;
                        localStorage.name = reception.name;
                    } else {
                        return;
                    }
                });
                var obj = {
                    vle: localStorage.guess || "a"
                };
                this.$http.post("guessWhat", obj).then(function (response) {
                    thisA.guessWhat = response.data;
                })
            },
            logOut: function () {
                var obj = {
                    "logOut": ""
                }
                this.$http.post("#", obj).then(function (response) {
                    var reception = response.data;
                    if (reception.registered) {
                        vm.loginSuccessfully = true;
                        vm.registerReveal = true;
                        vm.cancelRegister = true;
                        vm.items[1].bshwa = "";
                        vm.personalCenterReveal = false;
                    }
                })
            },
            
            //全部商品区
            obtainVle: function (index) {
                var thisA = this;
                var asds = this.searchHint[index].name.replace(new RegExp(`<span class="key">${this.searchDetails}</span>`, "g"), function ($) {
                    return thisA.searchDetails;
                });
                window.location.href=`/searchcontent.html?vle=${asds}`;
            },
            theGoods: function () {
                this.proExhi = !this.proExhi;
                this.proExhi ? (this.rotation = {}, this.DisplayIt = "点击隐藏") : (this.rotation = {
                    "transform": "rotateZ(-90deg)"
                }, this.DisplayIt = "点击显示");
            },
            //轮播图
            BySwitching: function () {
                this.eliminate = setInterval(function () {
                    vm.i++;
                    vm.i = vm.i % vm.slideshow.length;
                    vm.Switching = {
                        "left": "-800" * vm.i + "px",
                    };
                }, 2000)
            },
            slideshowS: function (index) {
                if (index) {
                    this.BySwitching();
                } else {
                    clearInterval(this.eliminate);
                }
            },
            SwitchP: function (index) {
                (index) ? ((this.i >= this.slideshow.length - 1) ? (this.i = 0) : (++this.i)) :
                ((this.i > 0) ? (--this.i) : (this.i = this.slideshow.length - 1));
                vm.Switching = {
                    "left": "-800" * vm.i + "px",
                };

            },
            skipPicture: function (index) {
                if (this.i == index) {
                    return;
                }
                this.i = index;
                vm.Switching = {
                    "left": "-800" * vm.i + "px",
                };
            },
            //获取html里面保存的数据在渲染
            drawingDa: function () {
                var thisA = this;
                this.$http.post("/tuijia").then(function (response) {
                    thisA.initDa = response.data;
                }).catch(function (err) {
                    console.log("报错了" + err)
                });
            },
            searchDa: function () {
                console.log(this.searchDetails == "");
                this.searchDetails = (this.searchDetails == "") ? (this.placeData) : (this.searchDetails);
                window.location.href = './searchcontent.html?vle=' + this.searchDetails;
            },
            contemove: function (index) {
                clearTimeout(this.contentDashow);
                this.contentDaTa = [];
                this.contentDaTa.push(this.contentDa[index]);
            },
            conteout: function () {
                var thisA = this;
                thisA.contentDashow = setTimeout(function () {
                    thisA.contentDaTa = [];
                }, 100)
            },
            contentDaout: function () {
                this.contentDaTa = [];
            },
            contentDaover: function () {
                clearTimeout(this.contentDashow);
            },
            searchFocus: function () {
                this.hintBool = true;
            },
            searchBlur: function () {
                setTimeout(function () {
                    this.hintBool = false;
                }, 100);
            }
        },
        mounted: function () {
            window.addEventListener('scroll', this.menu);
            this.init();
            if (localStorage.name == undefined) {
                this.items[0].bshwa = "";
            } else {
                this.items[0].bshwa = localStorage.name.substr(0, 4) + ((localStorage.name.length > 4) ? "..." : "");
            }
            this.BySwitching();
            this.drawingDa();
        },
        watch: {
            searchDetails: function (value) {
                if (this.searchDetails == "") {
                    this.searchHint = "";
                }
            },
            //搜索框
            searchDetails:function(){
                var thisA = this;
                if (this.searchDetails.length == 0 || this.searchDetails.match(/^\s+$/g)) {
                    clearTimeout(thisA.time);
                    this.searchHint.length = 0;
                    return;
                }
                clearTimeout(this.time);
                this.timer = setTimeout(function () {
                    thisA.ajax.apply(thisA, [10]);
                }, 300);
            }
        }
    })
})();
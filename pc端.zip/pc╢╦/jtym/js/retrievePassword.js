;
(function () {
    var vm = new Vue({
        el: "#app",
        data: {
            AboutUs: [{
                name: '注册',
                skip: './register.html'
            }, {
                name: '登录',
                skip: '/'
            }, {
                name: '关于我们',
                skip: "#javascript"
            }],
            introduction: ['关于我们', '合作伙伴', '联系客服', '开发平台', '联系我们', '广告服务', '友情链接'],
            account: "",
            auxiliaryPrompt: "请输入用户名/邮箱/已验证手机号",
            accountJudge: false,
            bool: false,
            maincenterReveal: true,
            mobileNumber: "",
            noteInformation: "获取短信验证码",
            phoneInformation: "",
            BtnaBreadth: "",
            BtnbBreadth: "",
            mobileError: "",
            messageBool: false,
            authCode: "",
            transmitter: false,
        },
        methods: {
            enter: function () {
                this.noteInformation = "";
                this.BtnaBreadth = "width:30px";
                this.BtnbBreadth = "width:130px";
                this.phoneInformation = "语音获取验证码";
            },
            leave: function () {
                this.phoneInformation = "";
                this.BtnbBreadth = "width:30px";
                this.BtnaBreadth = "width:130px";
                this.noteInformation = "获取短信验证码";
            },
            inquireNumber: function () {
                if (!this.authCode || !this.transmitter) {
                    return;
                }
                console.log("11111");
            },
            transmittedInformation: function (index, e) {
                this.transmitter = true;
                e = e || window.event;
                var i = 60,
                    s = "",
                    thisA = this;
                if (!index) {
                    e.target.setAttribute("disabled", "disabled");
                    this.BtnbBreadth = "display: none;"
                    this.BtnaBreadth = "width:160px;border: 1px solid #aaa;";
                }else{
                    e.target.setAttribute("disabled", "disabled");
                    this.BtnaBreadth = "display: none;"
                    this.BtnbBreadth = "width:160px;border: 1px solid #aaa;margin-left:15px;";
                }
                s = setInterval(function(){
                    i--;  
                    if(index){
                        thisA.phoneInformation ="重新获取验证码" + i +"s";
                    }else{
                        thisA.noteInformation = "重新获取验证码" + i +"s";
                    }
                    if(i == 0){
                        clearInterval(s);
                        e.target.disabled = false;
                        thisA.phoneInformation ="";
                        thisA.noteInformation = "获取短信验证码";
                        thisA.BtnbBreadth = "width:30px;display: inline-block;";
                        thisA.BtnaBreadth = "width:130px;display: inline-block";
                    }
                },1000)
            }
        }
    })

    function eventHandling() {
        this.slidingValidation = document.getElementsByClassName('slidingValidation')[0];
        this.slidingMove = this.slidingValidation.getElementsByClassName("slidingMove")[0] || "";
        this.slidingAbove = this.slidingValidation.getElementsByClassName("slidingAbove")[0];
        this.slidingGround = this.slidingValidation.getElementsByClassName("slidingGround")[0];
        this.keyboardMonitor = document.getElementsByClassName('keyboardMonitor')[0];
        this.nextStep = document.getElementsByClassName("nextStep")[0];
        this.xuqiao = document.getElementsByClassName("xuqiao")[0];
        this.eventJudge = false;
        this.cksf = false;
        this.SLDW = this.slidingGround.scrollWidth;
        this.SLMW = (this.slidingMove.scrollWidth) / 2;
        this.W;
    }
    eventHandling.prototype = {
        init: function () {
            this.initialization();
            this.addenvt();
        },
        initialization: function () {
            this.slidingMove.style.display = "block";
            this.slidingMove.style.left = '173px';
            this.slidingAbove.style.width = '0px';
            this.slidingAbove.innerHTML = "";
        },
        eventMousedown: function (e) {
            e = e || window.event;
            this.W = e.clientX;
            this.eventJudge = true;
        },
        eventMousemove: function (e) {
            if (this.eventJudge) {
                var X = e.clientX - this.W;
                if ((this.SLDW - this.SLMW >= X) && (X >= 0)) {
                    e = e || window.event;
                    this.slidingMove.style.left = e.clientX - this.W + 173 + 'px';
                    this.slidingAbove.style.width = e.clientX - this.W + this.SLMW + 'px';
                }
            }
        },
        eventMouseup: function (e) {
            if (!this.eventJudge) {
                return;
            }
            e = e || window.event;
            if (this.eventJudge) {
                this.eventJudge = false;
                if ((this.SLDW - this.SLMW) >= (e.clientX - this.W + this.SLMW)) {
                    this.slidingMove.style.left = '173px';
                    this.slidingAbove.style.width = '0px';
                    return;
                }
                this.cksf = true;
                this.slidingAbove.style.width = '350px';
                this.slidingAbove.innerHTML = "认证成功";
                this.slidingMove.style.display = 'none';
                if (!vm.account) {
                    vm.accountJudge = true;
                }
                (this.cksf && vm.account) ? (this.nextStep.style.cursor = 'pointer') : (this.nextStep.style.cursor = 'not-allowed')
            }
        },
        eventKeydown: function () {
            this.initialization();
            (this.cksf && vm.account && this.slidingAbove.innerHTML) ? (this.nextStep.style.cursor = 'pointer') : (this.nextStep.style.cursor = 'not-allowed')
        },
        eventClick: function () {
            if (this.cksf && vm.account && this.slidingAbove.innerHTML) {
                var obj = {};
                obj.number = vm.account;
                axios.post("#", obj).then(function (response) {
                    var reception = response.data;
                    if (reception.registered) {
                        vm.maincenterReveal = false;
                        vm.mobileNumber = vm.account.substr(0, 3) + "*****" + vm.account.substr(-3);
                    } else {
                        vm.messageBool = true;
                        vm.mobileError = "该账号不存在(如需通过海外手机找回请添加国际区号)";
                    }
                })
            }
            return;
        },
        xuqiaoClick: function () {
            vm.maincenterReveal = true;
            this.initialization();
        },
        addenvt: function () {
            this.slidingMove.addEventListener('mousedown', this.eventMousedown.bind(this), false);
            document.addEventListener('mouseup', this.eventMouseup.bind(this), false);
            document.addEventListener('mousemove', this.eventMousemove.bind(this), false);
            this.keyboardMonitor.addEventListener('keydown', this.eventKeydown.bind(this), false);
            this.nextStep.addEventListener("click", this.eventClick.bind(this), false);
            this.xuqiao.addEventListener("click", this.xuqiaoClick.bind(this), false);
        }
    }
    var eventHandlingA = new eventHandling();
    eventHandlingA.init();
})();
new Vue({
    el: "#app",
    data: {
        topName:"",
        regState: false,
        requestCen: false,
        reminder:false,
        use_id:"",
        registerName: "免费注册",
        topHref: "javascript:;",
        registerHref: "./register.html",
        reminderShow:null,
        searchDetails: "",
        placeData: "潮流T恤",
        reminderData:"",
        searchHint: [],
        saveData: "",
        hintBool: false,
        danqyemName: "",
        productData: "",
        thisAI: 0,
        select_Id: 0,
        shopNumber:1,
        shopSt:null,
        location: [{
            href: "/",
            vle: "",
            text: "首页"
        }],
        spec_listli: document.getElementsByClassName("spec_listli"),
        hotwords: ["华为特惠", "潮流T恤", "短裤", "新款男鞋", "时尚女包", "100减50", "男士外套"],
        ajax: function (index) {
            this.$http.get("/inquireData?vle=" + this.searchDetails).then(function (response) {
                var reception = response.data;
                if (reception.noThing == "0") {
                    this.hintBool = false;
                    return;
                } else {
                    this.hintBool = true;
                    this.saveData = reception;
                    if (reception.length > index) {
                        for (var i = 0; i > index; i++) {
                            this.searchHint[i] = reception[i];
                        }
                        return;
                    }
                    this.searchHint = reception;
                }
            })
        }
    },
    methods: {
        // 登录判断
        LoadPerform: function () {
            var thisA = this;
            this.$http.post('/personalCenter.html',{name:localStorage.name}).then(function (response) {
                var reception = response.data[0];
                if (response.data.noThing == "0") {
                    thisA.topHref= "/";
                    thisA.topName = (localStorage.name) ? (localStorage.name.substr(0, 4) + ((localStorage.name.length > 4) ? "...,请登录" : ",请登录")) : "你好,请登录";
                } else {
                    thisA.topName = "Hi,"+ reception.name;
                    thisA.use_id = reception._id;
                    thisA.registerName = "消息";
                    thisA.registerHref = "./personalCenter.html";
                    thisA.topHref = "./personalCenter.html";
                    thisA.regState = true;
                }
            })
            if (this.bshwa == "") {
                window.location.href = '/';
            }
        },
        searchDa: function () {
            this.searchDetails = (this.searchDetails == "") ? (this.placeData) : (this.searchDetails);
            window.location.href = './searchcontent.html?vle=' + this.searchDetails;
        },
        GetRequest: function () {
            var url = location.search; //获取url中"?"符后的字串  
            var theRequest = new Object();
            if (url.indexOf("?") != -1) {
                var str = url.substr(1);
                strs = str.split("&");
                for (var i = 0; i < strs.length; i++) {
                    theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                    if (i == strs.length - 1) {
                        theRequest.path = decodeURIComponent(str.substr(theRequest.id.length + 9, str.length - (theRequest.id.length + 9)));
                    }
                }
            }
            return theRequest;
        },
        productDetails: function (obj) {
            var thisA = this;
            this.$http.get("/particulars?_id=" + obj.id).then(function (response) {
                thisA.productData = response.data.data[0];
                console.log(thisA.productData);
                if (obj.path != 1) {
                    thisA.location.push({
                        href: "./searchcontent.html?vle=",
                        vle: obj.path,
                        text: obj.path
                    })
                }
                thisA.danqyemName = thisA.productData.name;
            }).catch(function (err) {
                console.log(err);
            })
        },
        commodidateImg: function (index) {
            if (index == this.thisAI) {
                return;
            }
            this.spec_listli[this.thisAI].classList.remove("present");
            this.spec_listli[index].classList.add("present");
            this.thisAI = index;
        },
        commodidate_l_box: function (e) {
            var commodidate_l_img_da = document.getElementsByClassName("commodidate_l_img_da")[0],
                commodidate_faj_img = document.getElementsByClassName("commodidate_faj_img")[0],
                commodidateImg = commodidate_faj_img.getElementsByTagName("img")[0],
                thisA = this;
            var e = e || window.event;
            thisA.pictureFz(commodidate_l_img_da, commodidate_faj_img, commodidateImg, e);
            commodidate_l_img_da.addEventListener("mousemove", function (e) {
                var e = e || window.event;
                thisA.pictureFz(commodidate_l_img_da, commodidate_faj_img, commodidateImg, e);
            })
        },
        pictureFz: function (dom1, dom2, dom3, e) {
            var x = e.clientX -125,
                y = e.clientY - 125;
            x = (x > 0) ? ((x > 250) ? (250) : (x)) : (0);
            y = (y > 0) ? ((y > 250) ? (250) : (y)) : (0);
            dom1.style.display = "block";
            dom2.style.display = "block";
            dom1.style.left = x + "px";
            dom1.style.top = y + "px";
            dom3.style.left = -x * 2 + "px";
            dom3.style.top = -y * 2 + "px";
        },
        commodidate_l_out: function () {
            var commodidate_l_img_da = document.getElementsByClassName("commodidate_l_img_da")[0],
                commodidate_faj_img = document.getElementsByClassName("commodidate_faj_img")[0];
            commodidate_l_img_da.style.display = "none";
            commodidate_faj_img.style.display = "none";
        },
        specListL: function () {
            if (this.thisAI == 0) {
                return;
            }
            this.spec_listli[this.thisAI].classList.remove("present");
            this.spec_listli[--this.thisAI].classList.add("present");
        },
        specListR: function () {
            if (this.thisAI == 1 || this.productData.img.length) {
                return;
            }
            this.spec_listli[this.thisAI].classList.remove("present");
            this.spec_listli[++this.thisAI].classList.add("present");
        },
        //改变物品数量
        changeNumber:function(index) {
            this.shopNumber = this.shopNumber * 1;  // 转换成number类型
            (this.shopNumber + index > 999 || this.shopNumber + index <= 0)?(this.shopNumber):(this.shopNumber += index);
        },
        // 加入购物车
        joinCart: function() {
            var quantity = this.shopNumber;
            if(!this.use_id && !this.reminder){     // 判断是否登录
                this.reminder = true;
                this.submitMiddle("你还未登录");
                return;
            }
            if(this.shopNumber.toString().match(/\D/g)){    // 判断数量是否合法
                this.reminder = true;
                this.submitMiddle("小伙子，请不要搞事！！！");
                return;
            }
            if(this.reminder || !this.regState ||quantity <= 0 || quantity >= 999){ // 判断数量是否是合理的数量
                return;
            }
            this.requestCen = true;
            var that = this;
            var obj = {
                buy_id:this.use_id,
                sell_id:this.productData.use_id,
                commodity_id:this.productData._id,
                type:this.productData.type[this.select_Id],
                vle:this.productData.vle,
                commodityName:this.productData.name,
                subheading: this.productData.subheading,
                imgSrc:this.productData.img,
                sell:this.productData.sell,
                quantity:quantity,
                pitch_on:true
            }
            
            this.$http.post("/addShopping",obj).then(function(result) {
                that.reminder = true;
                that.submitMiddle("已加入购物车");
            }).catch(function(err)  {
                that.reminder = true;
                that.submitMiddle("报错了:"+err);
            });
        },
        // 加到购物车时运行
        submitMiddle:function(text) {
            this.requestCen = false;
            this.reminderData = text;
            var that = this;
            setTimeout(function(){
                that.reminderShow = "opacity:0";
            },60);
            setTimeout(function(){
                that.reminder = false;
                that.reminderShow = null;
            },1000);
        }
    },
    mounted() {
        //获取url里面参数然后ajax请求
        var path = this.GetRequest();
        this.productDetails(path);
        this.LoadPerform();
    },
    watch: {
        // 搜索框
        searchDetails:function(){
            if (this.searchDetails.length == 0 || this.searchDetails.match(/^\s+$/g)) {
                clearTimeout(this.timer);
                this.searchHint.length = 0;
                return;
            }
            var thisA = this;
            clearTimeout(this.timer);
            this.timer = setTimeout(function () {
                thisA.ajax.apply(thisA, [10]);
            }, 300);
        },
        // 监听input输入,然后判断
        shopNumber:function(){
            clearTimeout(this.shopSt);
            var that = this;
            this.shopSt=setTimeout(function(){
                var regex = /\D/g;
                var padnum = that.shopNumber.toString().match(regex);
                if(that.shopNumber>999){
                    that.shopNumber = 999;
                }else if(that.shopNumber<=0 || padnum){
                    that.shopNumber = 1;
                }
            },500)
        }
    }
})
new Vue({
    el: "#app",
    data:{
        useData:{},
        goodsData:null,
        login_module:true,
        title_index: 0,
        quantity_Clt:null,
        all_pitch:false,
        prompt_dialog:false,
        present_index:null,
    },
    methods: {
        // 发送请求判断是否登录
        LoadPerform: function () {
            var thisA = this;
            this.bshwa = localStorage.name || "";
            if (this.bshwa == "") {
                window.location.href = '/';
            }
            axios.post('/personalCenter.html',{name:thisA.bshwa}).then(function (response) {
                if (response.data.noThing == "0") {
                    window.location.href = '/';
                } else {
                    thisA.useData = response.data[0];
                }
            }).catch(function(err) {
                window.location.href = '/';
            });
        },
        // 请求用户购物车数据信息
        vehicleData:function(id){
            var that = this;
            axios.post('/shoppingTr',{'id':id}).then(function(result) {
                var items = result.data;
                console.log(items)
                if(items.state == 0){
                    console.log(items.err)
                }else if(items.state == 1){
                    that.goodsData = items.data;
                }else if(items.state == 2){
                    console.log("数据为空");
                }else {
                    console.log("未知错误");
                }
                that.login_module = false;
                that.judge_pitch();
            }).catch(function(err) {
                console.log("报错了："+err)
                that.login_module = false;
            });
        },
        //设置选中那个商品标题
        alter_title:function(index) {
            var title_li = document.getElementsByClassName("content_ul_l")[0].getElementsByTagName("li");
            title_li[this.title_index].classList.remove("active");
            title_li[this.title_index = index].classList.add("active");
        },
        // 商品数量监听
        quantity_mon:function(index){
            console.log("aaaa"+index);
            clearTimeout(this.quantity_Clt);
            var that = this;
            this.quantity_Clt=setTimeout(function(){
                console.log("发送ajax请求");
            },500);
        },
        //  判断是否为全部选中
        judge_pitch:function() {
            var let = this.goodsData.length;
            for(var i = 0;i < let;i++){
                if(!this.goodsData[i].pitch_on){
                    this.all_pitch = false;
                    return;
                }
            }
            this.all_pitch = true;
        },
        // 点击全选
        cancel_pitch:function() {
            var let = this.goodsData.length;
            if(!let){
                return;
            }
            this.all_pitch = !this.all_pitch;
            for(var i = 0;i < let;i++){
                this.goodsData[i].pitch_on = this.all_pitch;
            }
            console.log("发送ajax请求改变选择")
        },
        // 确定从购物车里面删除次商品
        confirm_delete:function(){
            var arr = [];
            arr.push(this.goodsData[this.present_index]._id);
            this.prompt_dialog=false;
            this.login_module = true;
            this.commodity_remove(arr);
        },
        // 点击确认后从数据库里面删除此商品
        commodity_remove:function(arr){
            if(!arr.length){
                return;
            }
            var that = this;
            axios.post("/remove_commod",arr).then(function(result) {
                that.login_module = false;
                if(result.data.state == 1){
                    that.goodsData.splice(that.present_index,1);
                }else if(result.data.state == 2){
                    alert("错误删除")
                }
            }).catch(function(err) {
                console.log("报错了"+err)
                that.login_module = false;
            });
        }
    },
    mounted() {
        var that = this;
        this.LoadPerform();
        this.vehicleData(localStorage.id);
    },
})
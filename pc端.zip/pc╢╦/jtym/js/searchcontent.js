;
(function () {
    Vue.use(VueLazyload);
    new Vue({
        el: "#app",
        data: {
            bshwa: "",
            denlzc: false,
            enterAfterwards: false,
            personalCenterReveal: false,
            personalNews: false,
            personalCenterReveal: false,
            defaultImage: './img/mrtp.jpg',
            liveness: "430",
            loginSuccessfully: true,
            registerReveal: true,
            newsDetails: false,
            compositeData:  [{name:"首页",skip:"/"}, {name:"我的订单",skip:"./personalCenter.html"}, {name:"收藏夹",skip:"#javascript"}, {name:"联系客服",skip:"#javascript"}, {name:"lv会员",skip:"#javascript"}, {name:"网站导航",skip:"#javascript"}],
            mainNav: ["潮流", "客厅灯", "床垫", "电脑桌", "笔记本", "沙发", "拉杆箱", "收纳箱", "窗帘", "椅子", "牛仔裤"],
            section: null,
            itemDa: null,
            itemJudge: false,
            searchDetails: "",
            notFound: "",
            tiaohl:"",
        },
        methods: {
            ajax:function(){
                var thisA = this;
                this.bshwa = localStorage.name || "";
                this.$http.post('./personalCenter.html',{name:thisA.bshwa}).then(function (response) {
                    var reception = response.data[0];
                    if (response.data.noThing == "0") {
                        thisA.denlzc = false;
                        if (localStorage.name) {
                            this.bshwa = localStorage.name.substr(0, 4) + ((localStorage.name.length > 4) ? "..." : "")
                        } else {
                            this.bshwa = localStorage.name+",请登录";
                        }
                    } else {
                        thisA.denlzc = true;
                        thisA.bshwa = reception.name;
                    }
                })
            },
            according: function (index) {
                if (!index) {
                    this.personalCenterReveal = true;
                } else {
                    this.personalNews = true;
                }
            },
            hideIndividual: function (index) {
                if (!index) {
                    this.personalCenterReveal = false;
                } else {
                    this.personalNews = false;
                }
            },
            replacement: function () {
                this.loginSuccessfully = true;
                this.personalCenterReveal = false;
                this.enterAfterwards = false;
                this.registerReveal = true;
            },
            init: function (vle) {
                this.notFound = "正在拼命加载中.......";
                var thisA = this;
                this.$http.get("/searchcontent?vle=" + vle).then(function (response) {
                    thisA.section = [];
                    thisA.itemDa = response.data;
                    if (response.data.length > 16) {
                        for (var i = 0; i < 16; i++) {
                            if (thisA.section.indexOf(response.data[i].vle) == "-1") {
                                thisA.section[i] = response.data[i].vle;
                            }
                        }
                    } else {
                        for (var i = 0; i < response.data.length; i++) {
                            if (thisA.section.indexOf(response.data[i].vle) == "-1") {
                                thisA.section[i] = response.data[i].vle;
                            }
                        }
                    }
                    localStorage.setItem("guess",vle);
                    (thisA.section.length > 0) ? (thisA.itemJudge = true) : (thisA.itemJudge = false,thisA.notFound="找不到搜索的内容呢！",thisA.section = [localStorage.guess]);
                })
            },
            searchDa: function(){
                this.init(this.searchDetails);
            },
            searchmain: function(index){
                this.init(this.mainNav[index]);
            },
            sectioncli: function(index){
                this.init(this.section[index]);
            }
        },
        mounted: function () {
            var url = window.location.search;
            var str = url.substr(1)
            // strs = str.split("&");
            this.tiaohl = (decodeURIComponent(str.substr("vle".length + 1)));
            this.init(this.tiaohl);
            this.ajax();
        }
    })
})();
;
(function () {
    new Vue({
        el: "#app",
        data: {
            tableData: [],
            tableDataI: 0,
            tabulationData: [],
            tabulationDataLeg: null,
            zzcbox: false,
            value1: true,
            value2: false,
            use_id: "",
        },
        methods: {
            ajax(i, index) {
                var thisA = this;
                this.zzcbox = true;
                axios.get("/delete?i=" + index + "&use_id=" + thisA.use_id).then(function (response) {
                    thisA.zzcbox = false;
                    if (!response.data.hasOwnProperty("err")) {
                        thisA.tableData = response.data.data;
                    }
                }).catch(function (err) {
                    thisA.zzcbox = false;
                    console.log("报错了", err)
                })
                if (this.tabulationDataLeg > 6) {
                    this.tabulationDataLeg += i;
                }
            },
            datalet() {
                var thisA = this;
                axios.post("/datalet").then(function (response) {
                    if (!response.data.hasOwnProperty("err")) {
                        thisA.tabulationDataLeg = Math.ceil(response.data.dataLen / 10);
                        if (thisA.tabulationDataLeg > 6 + thisA.tableDataI) {
                            for (let i = 1; i <= 6; i++) {
                                thisA.tabulationData.push(i);
                            }
                            thisA.tabulationData.push("...");
                            return;
                        }
                        for (let i = 1; i <= thisA.tabulationDataLeg; i++) {
                            thisA.tabulationData.push(i);
                        }
                    }
                }).catch(function (err) {
                    console.log("报错了", err)
                })
            },
            handleEdit(index, row) {
                console.log(index, row);
            },
            handleDelete(index, row) {
                this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    var thisA = this,
                        erra = null;
                    axios.post("/success", {
                        "_id": this.tableData[index]._id
                    }).then(function (response) {
                        thisA.tableData.splice(index, 1);
                        if (response.data.hasOwnProperty("err")) {
                            erra = response.data.err;
                        }
                    }).catch(function (err) {
                        console.log(err + "报错了");
                    });
                    this.$message({
                        type: 'success',
                        message: erra || '删除成功!',
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            use_ajax: function () {
                var that = this;
                axios.post("/use_platform").then(function (res) {
                    if (res.data.status == 0) {
                        window.location.href = "./logo.html";
                    } else if (res.data.status == 1) {
                        that.use_id = res.data.id;
                        that.ajax(that.tableDataI,0);
                        that.datalet();
                    } else {
                        console.log("未知的错误!");
                    }
                }).catch(function (err) {
                    console.log("错误:" + err);
                })
            },
            use_quit:function(){
                axios.get("/use_quit").then(function(res){
                    console.log(res.data)
                    if(res.data.status == 1){
                        window.location.href = "./logo.html";
                    }else {
                        console.log("未知的错误!");
                    }
                })
            }
        },
        mounted() {
            this.use_ajax();
        },
    })
})()
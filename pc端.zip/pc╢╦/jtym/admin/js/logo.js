new Vue({
    el: "#app",
    data: {
        name: "",
        passwd: "",
        err: "",
        refreshImg: [],
        cancel_bool: false,
        canvasX: 0,
        canvasY: 0,
        canvasW: 360,
        canvasH: 150,
        canvasImg: 0,
        canvasArc_r: 6,
        shiftX: 0,
        slide_butt: 48,
    },
    methods: {
        //点击提交判断
        registerButt: function () {
            if (this.name == "") {
                this.err = "请输入账号!";
                return;
            } else if (this.passwd == "") {
                this.err = "请输入密码!";
                return;
            } else if (this.passwd.length < 6 || this.passwd.length > 16) {
                this.err = "密码长度不对!";
                return;
            }
            this.err = "";
            this.cancel_bool = true;
            var that = this;
            setTimeout(function(){
                that.scarce_all();
            },0); 
        },
        //点击刷新
        refresh: function (e) {
            this.refreshImg = [];
            var that = this;
            setTimeout(function () {
                that.refreshImg.push("refreshImg");
            }, 0)
            this.scarce_all();
            this.shift_failed();
        },
        //让滑块隐藏
        cancel: function () {
            this.cancel_bool = false;
        },
        //画一个缺口
        draw_scarce: function (ctx, x, y) {
            ctx.beginPath();
            ctx.lineWidth = "2";
            ctx.moveTo(x, y);
            var thatX = x + 18;
            ctx.lineTo(thatX, y);
            ctx.arc(thatX + this.canvasArc_r, y, 6, Math.PI, 0, false);
            thatX += this.canvasArc_r * 2 + 18;
            ctx.lineTo(thatX, y);
            thatY = y + 18;
            ctx.lineTo(thatX, thatY);
            ctx.arc(thatX, thatY + this.canvasArc_r, 6, -Math.PI / 2, Math.PI / 2, true);
            thatY += this.canvasArc_r * 2 + 18;
            ctx.lineTo(thatX, thatY);
            ctx.lineTo(x, thatY);
            ctx.closePath();
        },
        //画一个要被拼接的图片
        scarce_img: function () {
            var canvas = document.getElementsByClassName("canvas_box")[0],
                ctx = canvas.getContext("2d");
            canvas.width = this.canvasW;
            var img = new Image(),
                that = this;
            img.src = "./img/beij" + this.canvasImg + ".jpg"
            img.addEventListener("load", function () {
                ctx.drawImage(img, 0, 0);
                that.draw_scarce(ctx, that.canvasX, that.canvasY);
                ctx.fillStyle = '#333333'
                ctx.fill();
            })
        },
        //设置需要拼接的图片
        scarce_canva: function () {
            var canvas = document.getElementsByClassName("canvas_img")[0],
                ctx = canvas.getContext("2d");
            canvas.width = this.canvasW;
            this.draw_scarce(ctx, 0, this.canvasY);
            ctx.strokeStyle = "#666666";
            ctx.stroke();
            ctx.clip();
            var img = new Image(),
                that = this;
            img.src = "./img/beij" + this.canvasImg + ".jpg";
            img.addEventListener("load", function () {
                ctx.drawImage(img, that.canvasX, that.canvasY - that.canvasArc_r, 48, 54, 1, that.canvasY - that.canvasArc_r, 48, 56);
            })
        },
        //拼接滑块所有内容
        scarce_all: function () {
            this.canvasX = this.random_num(this.slide_butt, this.canvasW - this.slide_butt);
            this.canvasY = this.random_num(this.canvasArc_r, this.canvasH - this.slide_butt);
            this.canvasImg = this.random_num(1, 5);
            this.scarce_img();
            this.scarce_canva();
        },
        //按下滑块按钮
        shift_down: function (e) {
            var e = e || window.event;
            var canvas_img = document.getElementsByClassName("canvas_img")[0],
                slide_bg_butt = document.getElementsByClassName("slide_bg_butt")[0],
                slide_bg_back = document.getElementsByClassName("slide_bg_back")[0];
            this.shiftX = e.screenX;
            window.onmousemove = this.shift_move.bind(this, canvas_img, slide_bg_butt, slide_bg_back, this.shiftX);
            window.onmouseup = this.shift_up.bind(this, canvas_img, slide_bg_butt, slide_bg_back);
        },
        //移动滑块
        shift_move: function (domA, domB, domC, x, e) {
            var e = e || window.event;
            X = e.screenX - x;
            X = (X <= 0) ? (0) : ((X >= this.canvasW - this.slide_butt) ? (this.canvasW - this.slide_butt) : (X));
            domA.style.left = X + "px";
            domB.style.left = X + "px";
            domC.style.width = ((X + this.slide_butt) / this.canvasW) * 100 + "%";
            this.shiftX = X;
        },
        //滑块鼠标抬起事件
        shift_up: function (domA,domB,domC) {
            window.onmousemove = null;
            if (this.shiftX >= this.canvasX - 3 && this.shiftX <= this.canvasX + 3) {
                domB.style.display="none";
                domC.style.width = "100%";
                domC.innerHTML = "拼接成功";
                this.shift_ajax();
                window.onmouseup = null;
            }else{
                domA.style.transition = "left .5s";
                domB.style.transition = "left .5s";
                domC.style.transition = "width .5s";
                domC.style.backgroundColor = "#f00";
                domA.addEventListener("transitionend",function(){
                    domA.style.transition = "none";
                    domB.style.transition = "none";
                    domC.style.transition = "none";
                    domC.style.backgroundColor = "#23b8ff";
                })
                this.shift_failed();
            }
        },
        //验证失败
        shift_failed: function() {
            var canvas_img = document.getElementsByClassName("canvas_img")[0],
                slide_bg_butt = document.getElementsByClassName("slide_bg_butt")[0],
                slide_bg_back = document.getElementsByClassName("slide_bg_back")[0];
                canvas_img.style.left = "0";
                slide_bg_butt.style.left = "0";
                slide_bg_back.style.width = "0";
        },
        shift_ajax: function() {
            var obj = {
                "name":this.name,
                "passwoad":this.passwd
            },
            that = this;
            axios.post("/logoName",obj).then(function(res){
                if(res.data.status == 0){
                    that.err = "服务器错误!";
                }else if(res.data.status == 1){
                    window.location.href="/admin";
                }else if(res.data.status == 2){
                    that.err = "用户名或密码错误!";
                }else{
                    that.err = "未知错误!";
                }
                that.cancel();
            }).catch(function(err){
                console.log("错误:"+err);
            })
        },
        //产生一个min~max的随机数
        random_num: function (min, max) {
            return Math.floor(Math.random() * (max - min) + min);
        }
    },
    mounted() {
        
    },
})
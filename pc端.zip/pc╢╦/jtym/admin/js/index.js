;
(function () {
    new Vue({
        el: "#app",
        data: {
            vle: '',
            name: '',
            sell: '',
            file: '',
            subheading: '',
            bazaarPrice: '',
            costPrice: '',
            stock: '100',
            introduce: '',
            promptTitle: '',
            promptCont: '',
            promptClass: '',
            promptBox: 'prompt_img',
            zzcbox: false,
            use_id: '',
            use_name: '',
            type:[],
            product_type: 1,
        },
        methods: {
            getFile(event) {
                this.file = event.target.files[0];
            },
            submitForm(event) {
                console.log(this.recommend);
                this.promptBox = 'prompt_img';
                this.promptTitle = '操作提示';
                this.promptClass = "iconfont icon-tishi";
                var input = document.getElementsByTagName("input");
                var re = new RegExp(/^[\d]|[\d.\d]/);
                var rese = new RegExp(/[.]/ig);
                var photoExt = input[7].value.substr(input[7].value.lastIndexOf(".")).toLowerCase();
                if (!this.vle) {
                    this.promptCont = "产品类型不能为空";
                    input[0].focus();
                    return;
                } else if (!this.name) {
                    this.promptCont = "产品名称不能为空";
                    input[1].focus();
                    return;
                } else if (!this.subheading) {
                    this.promptCont = "产品标题不能为空";
                    input[2].focus();
                    return;
                } else if (!this.sell || !(re.test(this.sell)) || ((this.sell.match(rese)||[]).length > "1")) {
                    this.promptCont = "出售价格类型错误或为空";
                    input[3].focus();
                    return;
                } else if (!this.bazaarPrice || !(re.test(this.bazaarPrice)) || ((this.bazaarPrice.match(rese)||[]).length > "1")) {
                    this.promptCont = "市场价格类型错误或为空";
                    input[4].focus();
                    return;
                } else if(this.bazaarPrice*1 <= this.sell*1){
                    this.promptCont = "市场价格应该大于出售价格";
                    input[4].focus();
                    return;
                }else if (!this.costPrice || !(re.test(this.costPrice)) || ((this.costPrice.match(rese)||[]).length > "1")) {
                    this.promptCont = "成本价格类型错误或为空";
                    input[5].focus();
                    return;
                } else if (!this.stock || this.stock == "0") {
                    this.promptCont = "库存量不能小于1";
                    input[6].focus();
                    return;
                } else if (!this.file || (photoExt != ".gif" &&  photoExt != ".png" && photoExt != ".jpeg" && photoExt != ".jpg" && photoExt != ".bmp")) {
                    this.promptCont = "未选择产品图片或上传图片格式错误";
                    input[7].focus();
                    return;
                } else if (!this.introduce) {
                    this.promptCont = "产品介绍不能为空";
                    document.getElementsByTagName("textarea")[0].focus();
                    return;
                }else if( !this.type.length || this.type.length != this.product_type){
                    this.promptCont = "类别至少一项或不能为空";
                    input[8].focus();
                    return;
                }
                this.zzcbox = true;
                event.preventDefault();
                var formData = new FormData();
                var thisA = this;
                formData.append("use_id", this.use_id);
                formData.append("vle", this.vle);
                formData.append("name", this.name);
                formData.append("sell", (this.sell*1).toFixed(2));
                formData.append("tupian", this.file);
                formData.append("subheading", this.subheading);
                formData.append("bazaarPrice", (this.bazaarPrice*1).toFixed(2));
                formData.append("costPrice", (this.costPrice*1).toFixed(2));
                formData.append("stock", this.stock);
                formData.append("introduce", this.introduce);
                formData.append("type", this.type);
                axios.post("/admin/", formData).then(function (res) {
                    thisA.vle = '';
                    thisA.name = '';
                    thisA.sell = '';
                    thisA.file = '';
                    thisA.subheading = '';
                    thisA.bazaarPrice = '';
                    thisA.costPrice = '';
                    thisA.introduce = '';
                    input[7].value = "";
                    thisA.promptBox = "prompt_img promptChg";
                    thisA.promptCont = "操作成功";
                    thisA.promptClass = "iconfont icon-chenggong";
                    thisA.zzcbox = false;
                    input[0].focus();
                }).catch(function (err) {
                    console.log("报错了" + err);
                })
            },
            promptClick() {
                this.promptCont = "";
            },
            use_ajax: function(){
                var that = this;
                axios.post("/use_platform").then(function(res){
                    if(res.data.status == 0){
                        window.location.href = "./logo.html";
                    }else if(res.data.status == 1){
                        that.use_id = res.data.id;
                        that.use_name = res.data.name;
                        console.log(res.data);
                    }else {
                        console.log("未知的错误!");
                    }
                }).catch(function(err){
                    console.log("错误:"+err);
                })
            },
            use_quit:function(){
                axios.get("/use_quit").then(function(res){
                    console.log(res.data)
                    if(res.data.status == 1){
                        window.location.href = "./logo.html";
                    }else {
                        console.log("未知的错误!");
                    }
                })
            },
            type_add:function() {
                this.product_type++;
            },
            type_rem:function(){
                if(this.product_type <= 1){
                    return;
                }
                this.product_type--;
            },
            type_sub:function(){
                console.log(this.type)
            }
        },
        mounted() {
            this.use_ajax();
        },
    })
})()
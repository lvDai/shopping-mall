const share = require("../tool");
const MongoClient = share.MongoClient;
const url = share.url;
const ObjectId = share.objectId;


// 添加商品到购物车
module.exports.shopping = function (req, res) {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            res.end(JSON.stringify({
                err: "链接数据库出错了",
                state: 0,
            }));
            return;
        }
        var dbo = db.db("mongo").collection("shoppingCart");
        dbo.find({
            "commodity_id": req.body.commodity_id,
            "type": req.body.type
        }).toArray((err, items) => {
            if (err) {
                res.end(JSON.stringify({
                    err: "未知错误",
                    state: 0,
                }));
                return;
            }
            if (items.length) {
                addCommodity(dbo, items[0], req, res, db);
            } else {
                didnTCommodity(dbo, req, res, db);
            }
        })
    })
}

// 如果找到这个商品了
function addCommodity(dbo, data, req, res, db) {
    dbo.update(data, {
        $set: {
            quantity: data.quantity * 1 + req.body.quantity * 1
        }
    }, (err, items) => {
        if (err) {
            res.end(JSON.stringify({
                err: "添加商品失败",
                state: 0,
            }));
            return;
        }
        res.end(JSON.stringify({
            err: "",
            state: 1,
        }));
        db.close();
    })
}

// 如果没找到这个商品
function didnTCommodity(dbo, req, res, db) {
    dbo.insertOne(req.body, (err, result) => {
        if (err) {
            res.end(JSON.stringify({
                err: "未知错误",
                state: 0,
            }));
            return;
        }
        res.end(JSON.stringify({
            err: "",
            state: 1,
        }));
        db.close();
    })
}

// 返回购物车数据
module.exports.shoppingTr = function (req, res) {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            res.end(JSON.stringify({
                err: "链接数据库出错了",
                state: 0,
            }));
            return;
        }
        var dbo = db.db("mongo").collection("shoppingCart");
        dbo.find({
            "buy_id": req.body.id
        }).toArray((err, items) => {
            if (err) {
                res.end(JSON.stringify({
                    err: "访问数据库出错了",
                    state: 0,
                }));
                return;
            }
            if (items.length) {
                res.end(JSON.stringify({
                    err: "",
                    state: 1,
                    data: items
                }))
            } else {
                res.end(JSON.stringify({
                    err: "",
                    state: 2,
                    data: ""
                }))
            }
            db.close();
        })
    });

}
// 处理购物车删除商品
module.exports.remove_comm = function (req, res) {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            res.end(JSON.stringify({
                err: "链接数据库出错了",
                state: 0,
            }));
            return;
        }
        var dbo = db.db("mongo").collection("shoppingCart");
        dbo.remove({
            "_id": ObjectId(req.body[0])
        },  (err, items) => {
            if (err) {
                res.end(JSON.stringify({
                    err: "访问数据库出错了",
                    state: 0,
                }));
            }
            if (items.result.n) {
                res.end(JSON.stringify({
                    err: "",
                    state: 1,
                    data: items
                }))
            } else {
                res.end(JSON.stringify({
                    err: "",
                    state: 2,
                    data: ""
                }))
            }
            db.close();
        });
    })
}
const express = require("express");
const app = express();
const session = require('express-session');
const cookieParser = require('cookie-parser');
const MongoClient = require("mongodb").MongoClient;
const objectId = require("mongodb").ObjectId;
const url = "mongodb://localhost:27017/";

module.exports.MongoClient = MongoClient;
module.exports.url = url;
module.exports.objectId = objectId;
module.exports.cookies_se = function (name) {
    app.use(cookieParser());
    app.use(session({
        secret: 'recommand 128 bytes random string',
        name: name,
        resave: false,
        saveUninitialized: true
    }));
    app.all("*", function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
        res.header("X-Powered-By", ' 3.2.1');
        next();
    })
}
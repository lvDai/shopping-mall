const share = require("../tool");
const MongoClient = share.MongoClient;
const url = share.url;
share.cookies_se("logo");

exports.logo = function (req,res){
    let obj = {};
    MongoClient.connect(url,  (err, db) => {
        var dbo = db.db("mongo").collection("control");
        dbo.find(req.body).toArray((err,data) => {
            if(err){
                obj.status = 0;
                obj.err = err;
                return;
            }
            if(data.length){
                req.session.useName = data[0];
                obj.status = 1;
                obj.err = "";
            }else{
                obj.status = 2;
                obj.err = "";
            }
            db.close();
            res.end(JSON.stringify(obj));
        })
    })
}

exports.useLo = function(req,res){
    let obj = {};
    if(req.session.useName){
        obj.status = 1;
        obj.err = "";
        obj.name = req.session.useName.name;
        obj.id = req.session.useName._id;
    }else{
        obj.status = 0;
        obj.err = "用户还没有登录";
    }
    res.end(JSON.stringify(obj));
}
exports.useQuit = function(req,res){
    req.session.useName = "";
    res.end(JSON.stringify({"status":1}));
}